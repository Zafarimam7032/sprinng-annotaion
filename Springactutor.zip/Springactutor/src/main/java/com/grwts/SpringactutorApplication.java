package com.grwts;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringactutorApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringactutorApplication.class, args);
	}

}
