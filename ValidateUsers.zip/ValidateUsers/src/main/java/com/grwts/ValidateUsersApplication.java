package com.grwts;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ValidateUsersApplication {

	public static void main(String[] args) {
		SpringApplication.run(ValidateUsersApplication.class, args);
	}

}
