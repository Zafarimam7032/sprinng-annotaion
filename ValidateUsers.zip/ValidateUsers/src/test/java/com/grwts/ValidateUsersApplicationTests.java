package com.grwts;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ValidateUsersApplicationTests {

	@Test
	void contextLoads() {
	}

}
